export interface Insumo {
    id: number;
    nombre: string;
    descripcion: string;
    cantidad: number;
    unidad_medida: string;
    activo: boolean;
}