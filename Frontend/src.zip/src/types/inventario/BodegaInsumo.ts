export interface BodegaInsumo {
  id: number;
  bodega: number;  
  insumo: number;  
  cantidad: number;
}
