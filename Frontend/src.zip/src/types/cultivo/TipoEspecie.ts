export interface TipoEspecie {
    id?: number;
    nombre: string;
    descripcion: string;
    img: File | null;
  }
  