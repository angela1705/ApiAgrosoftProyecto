export interface Bancal {
    id?: number;
    nombre: string;
    TamX: number;
    TamY: number;
    posX: number;
    posY: number;
    fk_lote: number;
  }