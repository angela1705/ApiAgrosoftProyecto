export interface TipoActividad {
    id?: number;
    nombre: string;
    descripcion: string;
  }
  