interface Usuario {
    id: number;
    username: string;
    rol: string;

  }
  